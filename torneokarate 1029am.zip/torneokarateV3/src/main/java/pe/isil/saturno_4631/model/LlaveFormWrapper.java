package pe.isil.saturno_4631.model;

import java.util.List;

public class LlaveFormWrapper {
    private List<Llave> llaves;

    public List<Llave> getLlaves() {
        return llaves;
    }

    public void setLlaves(List<Llave> llaves) {
        this.llaves = llaves;
    }
}
