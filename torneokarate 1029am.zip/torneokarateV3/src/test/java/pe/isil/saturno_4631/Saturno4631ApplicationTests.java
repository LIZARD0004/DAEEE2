package pe.isil.saturno_4631;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Saturno4631ApplicationTests {

	@Test
	void contextLoads() {
	}

}
